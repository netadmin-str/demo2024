

                 VMware OVF Tool 4.6.0

System Requirements
-----------------------
VMware OVF Tool is supported on the following operating systems:

Windows 32-bit (x86) and 64-bit (x86_x64)
   Windows Vista
   Windows 2008
   Windows 7
   Windows 8
   Windows 2012
   Windows 8.1
   Windows 2013 R2
   Windows 10


Linux 32-bit (x86) and 64-bit (x86_x64)
   CentOS 6.x
   Fedora Core 14.x 15.x 16.x 17.x 18.x
   RedHat Enterprise Linux (RHEL) 6.x
   SUSE Enterprise Server 11.x
   Ubuntu Desktop 10.x 11.x 12.x

Mac OS X:
   Mac OS X 10.7
   Mac OS X 10.8
   Mac OS X 10.9
   Mac OS X 12.x

For changes see Release Notes.
Copyright 2022 VMware, Inc.  All rights reserved.
